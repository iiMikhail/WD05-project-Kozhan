CKEDITOR.editorConfig = function( config ) {
  config.fontSize = '18px';
  config.font_names = 'Open Sans;Arial;Tahoma;Verdana';
};
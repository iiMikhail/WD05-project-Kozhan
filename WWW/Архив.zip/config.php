<?php
	define('HOST', 'http://' . $_SERVER['HTTP_HOST'] . '/');
	define('ROOT', dirname(__FILE__) . '/');
// ProjPort123
	// define('SERVER_NAME', 'localhost');
	// define('USER_NAME', 'root');
	// define('USER_PASSWORD', 'root');
	// define('BD_NAME', 'project');
	define('SERVER_NAME', 'localhost');
	define('USER_NAME', 'mikhailkoz_proj');
	define('USER_PASSWORD', 'ProjPort123');
	define('BD_NAME', 'mikhailkoz_proj');

	define('SITE_NAME', 'Сайт-портфолио - WebDev-03');
	define('SITE_EMAIL', 'info@webdev03.com');
	define('ADMIN_EMAIL', 'info@admin.com');

	// define('HOST', 'http://' . $_SERVER['HTTP_HOST'] . '/');
	// define('ROOT', 'http://' . dirname(__FILE__) . '/');
?>